from scrapy import cmdline

cmdline.execute("scrapy crawl LJ".split())
